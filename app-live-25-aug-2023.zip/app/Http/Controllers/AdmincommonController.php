<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use App\Models\User;
use Hash;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExportOrderTransaction;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;

class AdmincommonController extends Controller
{
    public function userleads()
    {
        return view('backend.leads.index');
    }

    public function leadDestroy($id){
        $lead = Contact::find($id);
        $lead->delete();
        return redirect()->route('admin.dashboard.userleads')->with("message", "Lead removed successfully");
    }

    public function userslist(){
        $users = User::where('type', 0)->where('subscription','!=',"")->get();
        return view("backend.users.index", compact('users'));
    }

    public function usershow($id)
    {
        $user = User::find($id);
        return view("backend.users.show", compact('user'));
    }



    //ADMIN USERS METHODS
    public function adminuserslist(){
        $adminusers = User::whereIn("type", [1,3])->where("is_trainer", "!=", 1)->get();
        //dd($adminusers);
        return view('backend.admins.index', compact('adminusers'));
    }

    public function adminuseradd(Request $request){
        return view('backend.admins.add');
    }

    public function adminuserstore(Request $request){
        //dd($request);
        $validatedData = $request->validate([
            'name' => 'required|unique:users',
            'email' => 'required|email',
            'password' => 'required'
        ],[
            'name.required' => 'The name field is required',
            'email.required' => 'The field is required',
            'password.required' => 'The field is required',
        ]);

        $user = new User;
        $user->name = $request->name;
        $user->lastname = $request->lastname;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->type = 1;
        $user->save();

        $user->permissions()->sync($request->permission);

        return redirect()->route('admin.dashboard.admins')->with("message", "Admin user created succssfully");
    }

    public function adminuseredit($id){
        $adminuser = User::find($id);
        return view('backend.admins.edit', compact('adminuser'));
    }

    public function adminuserupdate(Request $request, $id){
        //dd($request);
        $validatedData = $request->validate([
            'name' => 'required',
            'email' => 'required|email',
        ],[
            'name.required' => 'The name field is required',
            'email.required' => 'The field is required',
        ]);

        $user = User::find($id);
        $user->name = $request->name;
        $user->lastname = $request->lastname;
        $user->email = $request->email;
        if($request->password != "") {
        $user->password = Hash::make($request->password);
        }
        $user->type = 1;
        $user->save();

        $user->permissions()->sync($request->permission);

        return redirect()->route('admin.dashboard.admins')->with("message", "Admin user created succssfully");
    }


    public function adminuserdestroy($id){
        $adminuser = User::find($id);
        $adminuser->delete();
        return redirect()->back()->with("message","Admin user deleted successfully");
    }



}
