<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Carbon\Carbon;
use App\Exports\UsersExport;
use App\Models\Order;

class AdminreportController extends Controller
{
    public function userreports(){
        $users = DB::table('users')->where('type', '0')->get();
        //$users = DB::table('users')->select('name', 'lastname','email', 'phone', 'subscription')->where('type', '0')->get();
        return view('backend.reports.user-reports', compact('users'));
    }

    public function exportUsers(){
        return Excel::download(new UsersExport, 'users.xlsx');
    }
    
    
    public function orderReports(Request $request){
        
        return view('backend.reports.order-report');
    }


    public function getOrderReportsByPeriod(Request $request){

        $request->validate(
            [
            'startdate' => 'required',
            'enddate' => 'required',
            ]
        );

        $start =  $request->startdate;
        $end =  $request->enddate;

        $datestart = date("Y-m-d", strtotime($start)); 
        $dateend = date("Y-m-d", strtotime($end));
   
        $orders = Order::whereBetween('created_at', [$datestart, $dateend])->get();

        return redirect()->back()->with( ['orders' => $orders, 'startdate'=> $datestart, 'enddate'=> $dateend] );

    }
    
    public function orderReportsExports(){
        
    }
    
    

    public function orderReportsResults(){

        return view('backend.reports.order-report-result');

    }
    


}
