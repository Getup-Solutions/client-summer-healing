<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdmintransactionController extends Controller
{
    public function index(){
        return "test";
    }
}
