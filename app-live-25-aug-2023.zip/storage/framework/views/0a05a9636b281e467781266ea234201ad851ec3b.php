<div class="navbar-header">
    <a class="navbar-brand" href="<?php echo e(url('/admin/dashboard')); ?>"><img src="<?php echo e(url('/')); ?>/backend/images/general_settings/1679276810.png" alt="Summer Healing Yoga"></a>
</div>

<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
    <span class="sr-only">Toggle navigation</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
</button>

<ul class="nav navbar-nav navbar-left navbar-top-links">
    <li><a href="<?php echo e(url("/")); ?>" target="_blank"><i class="fa fa-home fa-fw"></i>  View website</a></li>
</ul>

<ul class="nav navbar-right navbar-top-links">
    
    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
            <i class="fa fa-user fa-fw"></i> 
            <?php if(auth()->check()): ?> <?php echo e(auth()->user()->name); ?> <?php endif; ?> <b class="caret"></b>
        </a>
        <ul class="dropdown-menu dropdown-user">
            
            <?php if(!auth()->user()): ?>
            <li><a href="#"><i class="fa fa-gear fa-fw"></i> <?php echo e(__('Login')); ?></a></li>
            <li class="divider"></li>
            <?php else: ?>
            <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); 
            document.getElementById('logout-form').submit();"><i class="fa fa-sign-out fa-fw"></i> <?php echo e(__('Logout')); ?></a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
            <?php endif; ?>
        </ul>
    </li>
</ul>
<!-- /.navbar-top-links --><?php /**PATH /home/getuphostingcom/public_html/resources/views/layouts/admin/inc/topNav.blade.php ENDPATH**/ ?>