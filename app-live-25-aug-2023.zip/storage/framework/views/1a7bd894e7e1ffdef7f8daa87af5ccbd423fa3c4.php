<?php $__env->startSection('title', 'Admin | Courses'); ?>

<?php $__env->startSection('content'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<div id="page-wrapper">

    <div class="container-fluid">

            <div class="row">

                <div class="col-lg-12">

                    <div class="row">

                        

                        <h1 class="page-header">Classes

                            

                        </h1>

                        

                    </div>

                </div>

                <!-- /.col-lg-12 -->

            </div>

            <!-- /.row -->

            <?php          

                $userdata = App\Models\User::find(auth()->user()->id);

                $permissiondata = $userdata->permissions()->pluck('name');

                //dd($permissiondata);

            ?>



            <?php if($permissiondata->contains('courses.index') || $userdata->id == 1): ?>

            <div class="row">

                <div class="col-lg-12 col-md-12">

                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success">

                            <p><?php echo e($message); ?></p>

                        </div>

                    <?php endif; ?>



                    <div class="panel-body">

                        <div class="table-responsive">

                            <button id="dltall" style="display:none;margin-bottom: 10px" class="btn btn-danger delete_all" data-url="<?php echo e(route('admin.dashboard.course.deleteAll')); ?>">Delete All Selected</button>

                            <table class="table table-striped table-bordered table-hover" id="dataTables2">

                                <thead>

                                    <tr>

                                        <th width="50px"><input type="checkbox" id="master"></th>

                                        <th>#</th>

                                        <th>Title</th>

                                        <th>Featured Image</th>

                                        

                                        <th>Trainers</th>

                                        <th>Subscription</th>

                                        <th>Price</th>

                                        <th>Course</th>

                                        <th>Level</th>

                                        <th>Status</th>

                                        <th>Action</th>

                                    </tr>

                                </thead>

                                <tbody>

                                    <?php $i = 1 ?>

                                    <?php if(count($admincourses) > 0): ?>

                                    <?php $__currentLoopData = $admincourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admincourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>

                                        <td><input type="checkbox" class="sub_chk" data-id="<?php echo e($admincourse->id); ?>"></td>

                                        <td><?php echo e($i++); ?></td>

                                        <td class="main_page_title"><strong><?php echo e($admincourse->title); ?></strong></td>

                                        <td class="main_page_title"><img style="width:100px;" src="<?php echo e(asset("/backend/images/courses_images")); ?>/<?php echo e($admincourse->featured_image); ?>" alt="<?php echo e($admincourse->featured_image); ?>"></td>

                                        

                                        <td>

                                            <?php 

                                                $admin_trainers = $admincourse->admincoursetrainers;

                                            ?>

                                            <?php $__currentLoopData = $admin_trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php echo e($trainer->trainer_name); ?><?php if(!$loop->last): ?>,<?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </td>

                                        <td class="main_page_title">

                                            <?php $admin_subscrip = $admincourse->adminsubscriptions; 

                                                //dd($admin_subscrip[0]->title);

                                            ?>

                                            <?php echo e($admin_subscrip[0]->title); ?>


                                        </td>

                                        <td><?php echo e($admincourse->price); ?></td>

                                        <td>

                                            <?php if($admincourse->coursetype=="ondemand"): ?> <span class="coursecolor2">On Demand</span> <?php endif; ?>

                                            <?php if($admincourse->coursetype=="course"): ?> <span class="coursecolor1">Class</span> <?php endif; ?>

                                        </td>

                                        <td class="main_page_title"><?php echo e($admincourse->level); ?></td><td class="main_page_title"><?php echo e($admincourse->status); ?></td>

                                        <td>

                                            <ul class="actionList">

                                                

                                                <?php if($admincourse->coursetype == "course"): ?>

                                                <li><a href="<?php echo e(route('admin.dashboard.course.edit', $admincourse->id)); ?>?coursetype=course"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></li>

                                                <?php endif; ?>

                                                <?php if($admincourse->coursetype == "ondemand"): ?>

                                                <li><a href="<?php echo e(route('admin.dashboard.course.edit', $admincourse->id)); ?>?coursetype=ondemand"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></li>

                                                <?php endif; ?>

                                                <li>

                                                    <?php if($permissiondata->contains('courses.delete') || $userdata->id == 1): ?>

                                                    <form action="<?php echo e(route('admin.dashboard.course.destroy', $admincourse->id)); ?>" method="post">

                                                        <?php echo csrf_field(); ?>

                                                        <?php echo method_field('DELETE'); ?>

                                                        <button type="submit" id="deleteFormBtn" onclick="return confirm('<?php echo e(__('Are you sure you want to delete?')); ?>')">

                                                            <i class="fa fa-trash" aria-hidden="true"></i>

                                                        </button>

                                                    </form>

                                                </li>

                                                <?php endif; ?>

                                            </ul>

                                        </td>

                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php else: ?>

                                       

                                    <?php endif; ?>

                                </tbody>

                            </table>

                        </div>

                        <!-- /.table-responsive -->

                    </div>



                  

                </div>

             

            </div>

     

            <?php else: ?>

            <div class="permission_restricted">You don't have permission to view this page.</div>

            <?php endif; ?>

            <!-- /.col-lg-4 -->

        </div>

        <!-- /.row -->

    </div>

    <!-- /.container-fluid -->

</div>

<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>





<?php $__env->startSection('script'); ?>



<script>

  





//multiple delete function



$(document).ready(function () {

$("#master").val("");



$('#master').on('click', function(e) {

  

    if($(this).is(':checked',true)) {

        $("#dltall").css("display","block");

        $(".sub_chk").prop('checked', true);  

        

    } else {  

        

        $("#dltall").css("display","none");

        $(".sub_chk").prop('checked',false);  

    }  



});





$('.delete_all').on('click', function(e) {

    var allVals = [];  

    $(".sub_chk:checked").each(function() {  

        allVals.push($(this).attr('data-id'));

    });  



    if(allVals.length <=0){  

        alert("Please select row.");  

    }  else {  



        var check = confirm("Are you sure you want to delete this row?");  

        if(check == true){  

            var join_selected_values = allVals.join(","); 

            $.ajax({

                url: $(this).data('url'),

                type: 'DELETE',

                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},

                data: 'ids='+join_selected_values,

                success: function (data) {

                    if (data['success']) {

                        $(".sub_chk:checked").each(function() {  

                            $(this).parents("tr").remove(); 

                        });

                        $("#master").val("");

                        //alert(data['success']);

                        location.reload();



                    } else if (data['error']) {

                        alert(data['error']);

                    } else {

                        alert('Whoops Something went wrong!!');

                    }

                },



                error: function (data) {

                    alert(data.responseText);

                }

            });



          $.each(allVals, function( index, value ) {

              $('table tr').filter("[data-row-id='" + value + "']").remove();

          });

        }  

    }  

});











//DATA TABLES

$('#dataTables2').DataTable({

    responsive: true

});







});

</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/backend/courses/index.blade.php ENDPATH**/ ?>