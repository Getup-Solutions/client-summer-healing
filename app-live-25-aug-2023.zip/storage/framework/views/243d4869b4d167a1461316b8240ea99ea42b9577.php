<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Reset password'); ?>

<?php $__env->startSection('content'); ?>
 <!-- PAGE HEADING START -->
 <section class="set-top-spacing position-relative overflow-hidden">
    <div class="content d-flex align-items-center justify-content-center">
       <div class="container-fluid w-100">
          <div class="row">
             <div class="col-12 text-center mt-3 mt-sm-0">
                <h1 class="display-2 font-weight-700 text-uppercase mt-sm-0" data-sal="slide-up"
                   style="--sal-duration: 1s">
                   Reset Password
                </h1>
             </div>
          </div>
       </div>
    </div>
 </section>
 <!-- PAGE HEADING END -->
 <!-- SIGN IN START -->
 <section class="login spacing-100">
    <div class="container-fluid text-center text-xl-start">
      <div class="success_alert_wrap">
         <?php if(session('status')): ?>
         <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

         </div>
         <?php endif; ?>
      </div>

       <div class="row">
          <div class="col-xl-4 col-lg-7 col-md-8 col-sm-10 mx-auto">
         <div class="alert alert-success" role="alert">
            We just need to verify your email address <span class="text-primary"><?php if(auth()->check()): ?><?php echo e(auth()->user()->email); ?> <?php else: ?> <?php endif; ?></span> before you can reset the password.
         </div>
         <form method="POST" action="<?php echo e(route('password.email')); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-12 mb-sm-4 mb-3">
                    <div class="form-floating w-100">
                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Email"  name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                        <label for="floatingInput">Email</label>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-12 d-flex align-items-center justify-content-center mt-3">
                  <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                </div>
            </div>
          </form>
          </div>
       </div>
    </div>
 </section>
 <!-- SIGN IN END -->

 <?php $__env->stopSection(); ?>


 <?php $__env->startSection('style'); ?>
   <style>
      .success_alert_wrap div.alert {
         background: #13840a !important;
         text-align: center;
         padding-bottom: 10px;
         display: inline-block;
         padding-left: 2rem;
         padding-right: 2rem;
         padding-top: 10px;
      }
      .success_alert_wrap {
         text-align: center;
      }
   </style>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page.pageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>