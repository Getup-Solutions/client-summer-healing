
<?php $__env->startSection('title', 'Wellness Center Booking'); ?>
<?php $__env->startSection('meta_keyword', ''); ?>
<?php $__env->startSection('meta_description', ''); ?>
<?php $__env->startSection('content'); ?>
<!-- PAGE HEADING START -->
 <section class="spacing-150" id="welnesspagebooking">
    <div class="container">
       <?php
           //$id = $_GET['service'];
           //@dd($wellnesscenter->id)
       ?>

        <div class="bottom w-100 pt-5" data-sal="slide-up" style="--sal-duration: 3s" id="">
            <div class="row">
                <div class="col-xl-12 justify-content-center">
                    <form name="wellnessCenterForm" id="wellnessCenterForm" method="post" action="<?php echo e(route('page.wellness.wellnessbooksend', $wellnesscenter->id)); ?>#wellnessbooksuccess">
    
                    <h3 class="h2 text-uppercase text-center font-weight-700 mb-5 mt-5">
                        Wellness Center Booking
                    </h3>

                    
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success" id="wellnessbooksuccess">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                    <?php endif; ?>

                        <?php echo csrf_field(); ?>
                        <div class="row justify-content-center">
                            <div class="col-lg-6 mb-sm-4 mb-3">
                                <div class="form-floating w-100">
                                    <input type="text" id="name" class="form-control"
                                        name="name" placeholder="Name" value="<?php if(auth()->check()): ?> <?php echo e(auth()->user()->name); ?> <?php endif; ?>" value="<?php echo e(old('name')); ?>">
                                    <label for="floatingInput">Name</label>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-sm-4 mb-3">
                                <div class="form-floating w-100">
                                    <input type="text" id="email" class="form-control"
                                        name="email" placeholder="Email" value="<?php if(auth()->check()): ?> <?php echo e(auth()->user()->email); ?> <?php endif; ?>" value="<?php echo e(old('email')); ?>">
                                    <label for="floatingInput">Email</label>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-6 mb-sm-4 mb-3">
                                <div class="form-floating w-100">
                                    <input type="text" id="phone" class="form-control"
                                        name="phone" placeholder="Phone" value="<?php if(auth()->check()): ?> <?php echo e(auth()->user()->phone); ?> <?php endif; ?>" value="<?php echo e(old('phone')); ?>">
                                    <label for="floatingInput">Phone</label>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-sm-4 mb-3">
                                <div class="form-floating w-100">
                                    <select name="service" id="service" class="form-control">
                                        <option value="">--Select a service--</option>
                                        <?php
                                        if(isset($_GET['service'])){
                                            $selectedService = $_GET['service'];
                                        }
                                        ?>
                                        <?php $__currentLoopData = $wellnesscenterAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wellnesscenter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($selectedService == $wellnesscenter->id): ?> selected="selected" <?php endif; ?> value="<?php echo e($wellnesscenter->title); ?>"><?php echo e($wellnesscenter->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12 mb-sm-4 mb-3">
                                <div class="form-floating w-100">
                                    <textarea name="comment" id="comment" cols="20" rows="2" class="form-control" placeholder="Comment"><?php echo e(old('comment')); ?></textarea>
                                    <label for="floatingInput">Comment</label>
                                </div>
                            </div>
                        </div>

                        <div class="wellnessbookingbtnwrap text-right">
                            <button type="submit" class="btn btn-primary" id="wellnesscenterbookingbtn">Submit</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>





    </div>
 </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('style'); ?>
    <style>
        #service option {
            color: #333;
        }
        .wellnessbookingbtnwrap.text-right {
            text-align: right;
            display: flex;
            justify-content: flex-end;
            margin-top: 1rem;
        }
        .formAlertError.alert.alert-danger {
            color: #ea5959 !important;
            font-size: 14px;
            padding: 5px 0;
        }
        #welnesspagebooking #wellnessbooksuccess.alert.alert-success {
            background: #fec742 !important;
            text-align: center;
            color: #303030 !important;
            padding-bottom: 0;
            padding: 5px 0;
            margin-top: 4rem;
        }
        .container-fluid .alert {
            display: none;
        }
        .form-control::-webkit-input-placeholder { 
            color: #fff!important;
            opacity: 1;
        }
        .form-control::-moz-placeholder { 
            color: #fff!important;
            opacity: 1;
        }
        .form-control:-ms-input-placeholder { 
            color: #fff!important;
            opacity: 1;
        }
        .form-control:-moz-placeholder { 
            color: #fff!important;
            opacity: 1;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page.pageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/frontend/pages/wellnesscenterbook.blade.php ENDPATH**/ ?>