<?php $__env->startSection('title', 'Admin | Order Reports'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

    <div class="container-fluid">

                <div class="row">

                    <div class="col-lg-12">

                        <div class="row">

                            

                            <h1 class="page-header">Order Reports

                                <!--<span>-->

                                <!--    <a class="bgcolorOne" href="<?php echo e(route('admin.export-users')); ?>">-->

                                <!--    <i class="fa fa-plus" aria-hidden="true"></i>-->

                                <!--     Export</a>-->

                                <!--</span>-->

                            </h1>

                            

                        </div>

                    </div>

                    <!-- /.col-lg-12 -->

                </div>

                <!-- /.row -->

                <div class="row">

                    <div class="col-lg-12 col-md-12">

                        <div class="panel-body">

                            <form method="POST" action="<?php echo e(route('admin.getOrderReportsByPeriod')); ?>">

                                <?php echo csrf_field(); ?>

                                 <div class="form-group">

                                        <label>Start Date</label>

                                        <span class="datecal">

                                        <input type="text" placeholder="Select Date"  class="form-control <?php $__errorArgs = ['startdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="from" name="startdate" value="<?php echo e(old('startdate')); ?>">

                                        </span>

                                        <?php $__errorArgs = ['startdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                            <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>



                                    <div class="form-group">

                                        <label>End Date</label>

                                        <span class="datecal">

                                        <input type="text" placeholder="Select Date" class="form-control <?php $__errorArgs = ['enddate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="to" name="enddate" value="<?php echo e(old('enddate')); ?>">

                                        </span>

                                        <?php $__errorArgs = ['enddate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                            <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>


                                    <div>
                                        <button type="submit" class="btn btn-primary">Get Details</button>
                                    </div>

                            </form>

                        </div>

                    </div>

                </div>


                <div class="row">
                    
                <?php
                $orders = Session::get('orders');
                $startdate = Session::get('startdate');
                $enddate = Session::get('enddate');
                $i = 1;
                ?>
                
                
                    <div class="panel-body">
                        <?php if($orders): ?>
                            <?php if(count($orders) > 0): ?>
                                <div class="date-ranges">
                                    Showing result from <?php echo e(date('d-m-Y', strtotime($startdate))); ?> to <?php echo e(date('d-m-Y', strtotime($enddate))); ?>

                                    
                                    
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables1">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Address</th>
                                            <th>Order Item</th>
                                            <th>Qty</th>
                                            <th>Total</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($orders): ?>
                                            <?php if(count($orders) > 0): ?>
                                            
                                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($i++); ?></td>
                                                        <td><?php echo e(date('d-m-Y H:i', strtotime($order->created_at))); ?></td>
                                                        <td><?php echo e($order->username); ?></td>
                                                        <td><?php echo e($order->useremail); ?></td>
                                                        <td><?php echo e($order->userphone); ?></td>
                                                        <td><?php echo e($order->address); ?>, <?php echo e($order->state); ?>, <?php echo e($order->zip); ?> </td>
                                                        <td><?php echo e($order->course); ?></td>
                                                        <td><?php echo e($order->quantity); ?></td>
                                                        <td><?php echo e($order->total); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                    </div>

                </div>


            </div>

        </div>

        <!-- /.row -->

    </div>

    <!-- /.container-fluid -->

</div>

<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>



<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

 <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"> </script>

<script>

    $(document).ready(function() {

    //       from = $( "#from" ).datepicker({

    //           defaultDate: "+1w",

    //           changeMonth: true,

    //           numberOfMonths: 1,

    //           showOn: "button",

    //           buttonImage: '<?php echo e(asset("/backend/images/cal.png")); ?>',

    //           buttonImageOnly: true,

    //           //dateFormat: 'dd-mm-yy'

    //         })

    //         .on( "change", function() {

    //           to.datepicker( "option", "minDate", getDate( this ) );

    //         }),

    //       to = $( "#to" ).datepicker({

    //         defaultDate: "+1w",

    //         //minDate: 0,

    //         changeMonth: true,

    //         numberOfMonths: 1,

    //         showOn: "button",

    //         buttonImage: '<?php echo e(asset("/backend/images/cal.png")); ?>',

    //         buttonImageOnly: true,

    //         //dateFormat: 'dd-mm-yy'

    //       })

    //   .on( "change", function() {

    //     from.datepicker( "option", "maxDate", getDate( this ) );

    //   });

 

    //     function getDate( element ) {

    //       var date;

    //       try {

    //         date = $.datepicker.parseDate( dateFormat, element.value);

    //       } catch( error ) {

    //         date = null;

    //       }

    //       //console.log(moment(element.value).format('DD-MM-YYYY'));
    //       return date;

    //     }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    $( function() {
    var dateFormat = "mm/dd/yy",
      from = $( "#from" )
        .datepicker({
          defaultDate: "+1w",
          changeMonth: true,
          numberOfMonths: 1,
          showOn: "button",
          buttonImage: '<?php echo e(asset("/backend/images/cal.png")); ?>',
          buttonImageOnly: true,
        })
        .on( "change", function() {
          to.datepicker( "option", "minDate", getDate( this ) );
        }),
      to = $( "#to" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
        showOn: "button",
        buttonImage: '<?php echo e(asset("/backend/images/cal.png")); ?>',
        buttonImageOnly: true
      })
      .on( "change", function() {
        from.datepicker( "option", "maxDate", getDate( this ) );
      });
 
    function getDate( element ) {
      var date;
      try {
        date = $.datepicker.parseDate( dateFormat, element.value );
      } catch( error ) {
        date = null;
      }
 
      return date;
    }
  } );
  
  

  
          
        $('#dataTables1').DataTable({
            responsive: true,
            paging: false,
            pageLength: 30
        });




        

        

        

    });

</script>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('style'); ?>

<style>

    .datecal {

        position: relative;

        display: block;

        width: 200px;

    }

    .datecal img {

        position: absolute;

        right: 10px;

        top: 50%;

        transform: translateY(-50%);

        width: 15px;

    }
    
    .date-ranges {
      font-size: 17px;
      color: #bb8a45;
      font-weight: 600;
    }

</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/backend/reports/order-report.blade.php ENDPATH**/ ?>