<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title', 'Events | Summer Healing Society'); ?>

<?php $__env->startSection('meta_keyword', 'Events'); ?>

<?php $__env->startSection('meta_description', 'Events'); ?>

 <!-- MY ACCOUNT START -->

 <section class="set-top-spacing">

    <div class="container-fluid">

      <!-- EVENTS START -->

        <div class="row text-center text-xl-start">

            <div class="col-xl-11 mx-auto">

                <h2 class="display-2 text-center text-uppercase font-weight-700 mb-lg-4">Upcoming events</h2>

             <!-- EVENTS START -->

                <div class="my-events pt-5">

                   

                    <?php if(count($events) > 0): ?>

                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    

                    <?php if($event->enddate > date("Y-m-d")): ?>

                    <!-- EVENT START -->

                    <div class="event" data-sal="slide-up" style="--sal-duration: 1s">

                        <div class="left-">

                            <div class="thumb">

                                <img src="assets/images/loading.gif" data-src="<?php echo e(asset("/backend/images/events_images")); ?>/<?php echo e($event->image); ?>"

                                class="d-block w-100 lazy" style="object-fit: cover;" alt="...">

                                

                            </div>

                            <div class="short-info">

                                <a href="<?php echo e(route('page.event.detailed', $event->id)); ?>">

                                    <h3 class="h2 text-uppercase font-weight-700 mb-xl-2 mb-3"><?php echo e($event->title); ?>


                                         

                                    </h3>

                                    <p class="desc"><?php echo Str::limit(strip_tags($event->description), 50); ?></p>

                                </a>

                                <div class="venu-date mt-2 d-xl-flex align-items-center align-items-start">

                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" fill="none"

                                        viewBox="0 0 17 17">

                                        <path stroke="#FDC442" stroke-linecap="round" stroke-linejoin="round"

                                            d="M8.5 9.031a2.125 2.125 0 1 0 0-4.25 2.125 2.125 0 0 0 0 4.25Z" />

                                        <path stroke="#FDC442" stroke-linecap="round" stroke-linejoin="round"

                                            d="M13.813 6.906c0 4.782-5.313 8.5-5.313 8.5s-5.313-3.719-5.313-8.5a5.312 5.312 0 1 1 10.626 0v0Z" />

                                    </svg>

                                    <?php

                                        $date = strtotime($event->startdate);

                                        $month = date("F",$date);

                                        $day = date("d",$date);

                                        //dd($day);

                                        $monthOfEvent = strtoupper($month);

                                        $dayOfEvent = strtoupper($day);

                                    ?>  

                                    <span class="d-block d-xl-inline-block mt-3 mt-xl-0 ms-xl-1"><?php echo e($event->venue); ?>,

                                        <span class="text-primary d-xl-inline-block d-block mt-1 mt-xl-0"><?php echo e($monthOfEvent); ?> <?php echo e($dayOfEvent); ?> <?php echo e($event->starttime); ?></span> 

                                    </span>

                                </div>

                            </div>

                        </div>

                        <div class="right- mt-5 mt-xl-0">

                            <a href="<?php echo e(route('page.event.book', $event->id)); ?>" class="btn btn-primary"><?php if($event->buttontext != ""): ?> <?php echo e($event->buttontext); ?> <?php else: ?> get tickets <?php endif; ?></a>

                            <a href="<?php echo e(route('page.event.detailed', $event->id)); ?>" class="btn ">more info</a>

                        </div>

                    </div>

                    <?php endif; ?>

                    <!-- EVENT END -->

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>

                    

                </div>

                <!-- EVENTS END -->

            </div>

        </div>

        <!-- EVENTS END -->

    </div>

</section>

<!-- MY ACCOUNT END -->





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page.pageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/frontend/pages/events.blade.php ENDPATH**/ ?>