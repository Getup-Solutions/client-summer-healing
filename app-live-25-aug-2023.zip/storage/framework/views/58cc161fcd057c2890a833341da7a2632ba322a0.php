
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Course Detailed'); ?>
<?php $__env->startSection('meta_keyword', 'Course Detailed'); ?>
<?php $__env->startSection('meta_description', 'Course Detailed'); ?>
<!-- HEADER END -->
<section class="set-top-spacing" data-sal="slide-up" style="--sal-duration: 1s">
    <div class="container-fluid">
        <div class="row text-center text-xl-start">
            <div class="col-xl-11 mx-auto">
                <h2 class="display-4 text-center text-uppercase font-weight-700 mb-lg-4"><?php echo e($course->title); ?></h2>
                <?php if($course->excerpt): ?>
                <div class="text-center"><?php echo $course->excerpt; ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<section class="course-single mt-sm-5 mt-3">
    <!-- COURSE SINGLE START -->
    <!-- BANNER START -->
    <div class="banner init-animation" data-sal="slide-up" style="--sal-duration: 1s">
        <div class="image-holder image-round image-overlay">
            <div id="carouselExampleControls" class="carousel slide carousel-fade" data-bs-ride="carousel"
                data-bs-touch="false" data-bs-interval="3000">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="assets/images/loading.gif" data-src="<?php echo e(asset('Frontend/assets/images/single-1.jpg')); ?>"
                            class="d-block w-100 lazy" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="assets/images/loading.gif" data-src="<?php echo e(asset('Frontend/assets/images/single-2.jpg')); ?>"
                            class="d-block w-100 lazy" alt="...">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- BANNER END -->
    <!-- COLUMNS WRPR START  -->
    <div class="row g-0">
        <div class="col-xl-11 mx-auto">
            <div class="container-fluid position-relative clearfix column-wrpr">
                <!-- LEFT COLUMN START -->
                <div class="col-left mb-4 mb-xl-0">
                    <!-- CARD START -->
                    <div class="card w-100 init-animation" data-sal="slide-up" style="--sal-duration: 1s">
                        <h3 class="h3 m-0 text-uppercase font-weight-700">Description</h3>
                        <p><?php echo $course->description; ?></p>
                    </div>
                    <!-- CARD END -->
                    <!-- CARD START -->
                    <div class="card w-100" data-sal="slide-up" style="--sal-duration: 1s">
                        <h3 class="h3 m-0 text-uppercase font-weight-700">Trainers</h3>
                        <?php 
                            $admin_trainers = $course->admincoursetrainers;
                        ?>
                        <ul class="list-unstyled list-trainers mt-3">
                            <?php $__currentLoopData = $admin_trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="d-flex align-items-center justify-content-start">
                                <img src="assets/images/loading.gif" data-src="<?php echo e(url("/backend/images/trainers_images")); ?>/<?php echo e($trainer->image); ?>"
                                    class="d-block w-100 lazy trainer-photo" alt="...">
                                <div class="info ms-3">
                                    <h5 class="trainer-name"><?php echo e($trainer->trainer_name); ?></h5>
                                    <p class="m-0">Yoga Instructor</p>
                                </div>
                            </li>
                            <?php if(!$loop->last): ?>,<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <!-- CARD END -->
                </div>
                <!-- LEFT COLUMN END -->
                <!-- RIGHT COLUMN START -->
                <div class="col-right position-sticky mt-5 mt-xl-0">
                    <div class="ps-xl-5">
                        <div class="card card-price" data-sal="slide-up" style="--sal-duration: 1s">
                            <div class="d-flex align-items-center justify-content-between w-100">
                                <h5 class="m-0 text-white w-100 text-center"><span
                                        class="text-muted me-3 font-weight-500 h2"><s>$<?php echo e($course->price + 100); ?></s></span><span
                                        class="display-3 font-weight-700">$<?php echo e($course->price); ?></span></h5>
                            </div>
                            <?php if(session('cart')): ?>
                                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($details['title'] === $course->title): ?>
                                    <a href="#" class="btn btn-primary w-100 addedcarts">Added to cart</a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('add.to.cart', $course->id)); ?>" class="btn btn-primary w-100">Buy now</a>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>

                                <?php if(auth()->check()): ?>
                                    <?php if($courseByUser->contains($course->id)): ?>

                                    <?php else: ?>
                                        <a href="<?php echo e(route('add.to.cart', $course->id)); ?>" class="btn btn-primary w-100">Buy now</a>                                    
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="<?php echo e(route('add.to.cart', $course->id)); ?>" class="btn btn-primary w-100">Buy now</a>  
                                <?php endif; ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <!-- RIGHT COLUMN WRPR START -->
            </div>
        </div>
    </div>
    <!-- COLUMNS END  -->
    <!-- COURSE SINGLE END -->
    <!-- MORE COURSES START -->
    <section class="yoga-course yoga-course-inner spacing-150 pb-0">
        <div class="container-fluid text-center text-md-start">
            <div class="row">
                <div class="col-xl-11 mx-auto">
                    <h2 class="display-2 text-center text-uppercase font-weight-700 mb-0 mb-sm-5">More courses
                    </h2>
                    <div class="row row-equl pt-sm-5 pt-4 pb-0">
                        <?php
                            $coursesAll = App\Models\Admincourse::where('id', '!=', $course->id)->get();
                            //dd($courses)
                        ?>
                        <?php if($coursesAll): ?>
                        <?php $__currentLoopData = $coursesAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseOther): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- ITEM START -->
                        <div class="col-xl-4 col-lg-6 mb-5" data-sal="slide-up" style="--sal-duration: 1s">
                            <div class="card text-center mx-2">
                                <div class="top">
                                    <img src="assets/images/loading.gif" data-src="<?php echo e(asset('Frontend/assets/images/thumb-1.webp')); ?>"
                                class="d-block w-100 lazy" alt="...">
                                </div>
                                <div class="content">
                                    <div class="middle">
                                        <a href="yoga-course-single.html"><h4 class="h4 font-weight-700 text-uppercase"> <?php echo e($courseOther->title); ?></h4></a>
                                        <h5 class="display-5 m-0 text-white"><span
                                                class="text-muted me-3 font-weight-500"><s>$<?php echo e($courseOther->price + 100); ?></s></span><span
                                                class="font-weight-700"><?php echo e($courseOther->price); ?></span></h5>
                                    </div>
                                    <div class="bottom w-100 d-sm-flex align-items-end justify-content-center">
                                        <a href="<?php echo e(route('page.yogacourse.detail', $courseOther->slug)); ?>" class="btn me-3 w-100">More Info</a>
                                        <a href="<?php echo e(route('add.to.cart', $courseOther->id)); ?>" class="btn btn-primary w-100 mt-3 mt-sm-0">Buy
                                            Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ITEM END -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- MORE COURSES END -->
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page.pageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/frontend/pages/course-detailed.blade.php ENDPATH**/ ?>