<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('layouts.admin.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <div id="wrapper">
            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <?php echo $__env->make('layouts.admin.inc.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('layouts.admin.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>

            <?php echo $__env->yieldContent('content'); ?>

            

        </div>
        <!-- /#wrapper -->
        <?php echo $__env->make('layouts.admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

        <script>
            $(document).ready(function() {
            <?php if(Session::has('message')): ?>
            toastr.options =
            {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-top-right",
            }
            toastr.success("<?php echo e(session('message')); ?>");
            <?php endif; ?>
            
            <?php if(Session::has('error')): ?>
            toastr.options =
            {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-top-right",
            }
            toastr.error("<?php echo e(session('error')); ?>");
            <?php endif; ?>
            
            <?php if(Session::has('info')): ?>
            toastr.options =
            {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-top-right",
            }
            toastr.info("<?php echo e(session('info')); ?>");
            <?php endif; ?>
            
            <?php if(Session::has('warning')): ?>
            toastr.options =
            {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-top-right",
            }
            toastr.warning("<?php echo e(session('warning')); ?>");
            <?php endif; ?>
            }); 


            $(document).ready(function(){
                $(".minimizeSidebar").click(function(){
                    $(this).toggleClass('actionActive');
                    $(".sidebar-nav").toggleClass('actionHideSidebar');
                    $("#page-wrapper").toggleClass("displayaction");
                });
            });


        </script>
        <?php echo $__env->yieldContent('script'); ?>
        <?php echo $__env->yieldContent('style'); ?>
    </body>
</html>
<?php /**PATH /home/getuphostingcom/public_html/resources/views/layouts/admin/adminLayout.blade.php ENDPATH**/ ?>