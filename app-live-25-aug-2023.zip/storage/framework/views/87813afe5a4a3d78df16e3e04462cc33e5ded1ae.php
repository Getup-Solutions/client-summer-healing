<!-- jQuery -->
<script src="<?php echo e(asset('backend/js/jquery.min.js')); ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('backend/js/bootstrap.min.js')); ?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo e(asset('backend/js/metisMenu.min.js')); ?>"></script>

<!-- Morris Charts JavaScript -->


<!-- Custom Theme JavaScript -->
<script src="<?php echo e(asset('backend/js/startmin.js')); ?>"></script>
<script src="<?php echo e(asset('backend/script.js')); ?>"></script>

<!-- DataTables JavaScript -->
<script src="<?php echo e(asset('backend/js/dataTables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/dataTables/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>

<script>
    // $(document).ready(function() {
    //     $('#dataTables-example').DataTable({
    //             responsive: true
    //     });
    // });

    (function($){
        $(window).on("load",function(){
            $(".sidebar-nav").mCustomScrollbar();
        });
    })(jQuery);
</script><?php /**PATH /home/getuphostingcom/public_html/resources/views/layouts/admin/inc/footer.blade.php ENDPATH**/ ?>