<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title', 'Yoga Courses | Summer Healing Society'); ?>

<?php $__env->startSection('meta_keyword', 'Yoga Courses'); ?>

<?php $__env->startSection('meta_description', 'Yoga Courses'); ?>



<!-- PAGE HEADING START -->

<section class="set-top-spacing position-relative overflow-hidden">

    <div class="content d-flex align-items-center justify-content-center">

          <div class="container-fluid w-100">

             <div class="row">

                <div class="col-12 text-center mt-3 mt-sm-0">

                      <h1 class="display-2 font-weight-700 text-uppercase" data-sal="slide-up"

                         style="--sal-duration: 1s">
                         Yoga Classes
                      </h1>
                </div>

             </div>

          </div>

    </div>

 </section>

 <!-- PAGE HEADING END -->



<!-- PLANS START -->

<section class="yoga-course yoga-course-inner spacing-100 pb-0">

    <div class="container-fluid text-center text-md-start">

        <div class="row">

            <div class="col-xl-11 mx-auto">

                <div class="row row-equl">

                    <?php if(count($coursesAll) > 0): ?>

                    <?php $__currentLoopData = $coursesAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <!-- ITEM START -->

                    <div class="col-xl-4 col-lg-6 mb-5" data-sal="slide-up" style="--sal-duration: 1s">

                        <div class="card text-center mx-2">

                            <?php

                            $subscription = App\Models\Adminsubscription::where('id', $course->subscription)->first();

                                //@dd($subscription->title);

                            ?>

                            <?php if(auth()->check()): ?>

                                <?php if( $subscription->id == $userActiveSubscription && $userActiveSubscriptionstatus == "active"): ?>

                                <span id="subscriptionplan"><?php echo e($subscription->title); ?></span>

                                <?php else: ?>

                                <?php endif; ?>

                            <?php endif; ?>

                            <div class="top">

                                <?php if($course->featured_image): ?>

                                  <img src="frontend/assets/images/loading.gif" data-src="<?php echo e(asset('backend/images/courses_images')); ?>/<?php echo e($course->featured_image); ?>" class="d-block w-100 lazy" alt="...">

                                <?php else: ?>

                                <img src="<?php echo e(asset('backend/images/courses_images/common_banner.jpg')); ?>" class="d-block w-100" alt="" />

                                <?php endif; ?>

                            </div>

                            <div class="content">

                                <div class="middle">

                                    <a href="<?php echo e(route('page.yogacourse.detail', $course->slug)); ?>">

                                        <h4 class="h4 font-weight-700 text-uppercase">

                                            <?php echo e($course->title); ?> 

                                            <span style="font-size:14px;text-transform:lowercase!important;">

                                                (<?php echo e($course->coursetype == "ondemand" ? "On Demand" : "Class"); ?>)

                                            </span>

                                        </h4>

                                    </a>

                                    <h5 class="display-5 m-0 text-white">

                                        <span class="text-muted me-3 font-weight-500" style="display:none;!important"><?php if($course->price > 0): ?> $<?php echo e($course->price + 100); ?> <?php endif; ?></span>

                                        <span class="font-weight-700"><?php if($course->price == 0): ?> Free <?php else: ?> $<?php echo e($course->price); ?> <?php endif; ?></span></h5>

                                </div>

                                <div class="bottom w-100 d-sm-flex align-items-end justify-content-center">



                                    <?php if(auth()->check()): ?>

                                        <?php if($subscription->id == $userActiveSubscription && $userActiveSubscriptionstatus == "active" || in_array($course->id, $userAllCourses)): ?>

                                        <a href="<?php echo e(route('user.myaccount.coursedetails', $course->id)); ?>?coursetype=<?php echo e($course->coursetype); ?>" class="btn me-3 w-100">View Class</a>



                                        <?php else: ?>

                                        <a href="<?php echo e(route('page.yogacourse.detail', $course->slug)); ?>" class="btn me-3 w-100">More Info</a>

                                        <a href="<?php echo e(route('add.to.cart', $course->id)); ?>" class="btn btn-primary w-100 mt-3 mt-sm-0">Buy Now</a>

                                        <?php endif; ?>



                                    <?php else: ?>

                                        <a href="<?php echo e(route('page.yogacourse.detail', $course->slug)); ?>" class="btn me-3 w-100">More Info</a>

                                        <a href="<?php echo e(route('add.to.cart', $course->id)); ?>" class="btn btn-primary w-100 mt-3 mt-sm-0">Buy Now</a>

                                    <?php endif; ?>

                                </div>

                            </div>

                        </div>

                    </div>

                    <!-- ITEM END -->

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>

</section>

<!-- PLANS END -->

<?php $__env->stopSection(); ?>





<?php $__env->startSection('style'); ?>

<style>

    #subscriptionplan {

        position: absolute;

        top: 4px;

        z-index: 111;

        background: #fdc642;

        right: 21px;

        border-radius: 0 0px 0 0;

        font-size: 11px;

        padding: 0 12px;

    }

</style>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('script'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page.pageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/frontend/pages/yogacourses.blade.php ENDPATH**/ ?>