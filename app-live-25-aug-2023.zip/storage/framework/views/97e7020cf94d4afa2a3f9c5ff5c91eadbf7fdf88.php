<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('layouts.page.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'meta-description'); ?>">
        <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keyword', 'meta-keyword'); ?>">
    </head>
    <body>
        <!-- PAGELOADING START-->
        
        <!-- PAGELOADING END-->
        <!-- MAIN WRAPPER START -->
        <div class="main-wrpr">
            <?php echo $__env->make('layouts.page.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('layouts.page.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- MAIN WRAPPER END -->
        <!-- BACKGROUND VIDEO START -->
        <div class="video-wrapper">
            <video autoplay muted loop>
                <source src="<?php echo e(asset('Frontend/assets/video/video.mp4')); ?>" type="video/mp4">
            </video>
        </div>
        <!-- BACKGROUND VIDEO END -->
        <script src="<?php echo e(asset('Frontend/assets/scripts/jquery.min.js')); ?>"></script>
        
        <script src="<?php echo e(asset('Frontend/assets/scripts/theme.js')); ?>" async></script>
        
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

        <script>
            $(document).ready(function() {
            <?php if(Session::has('message')): ?>
            toastr.options =
            {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-bottom-right",
            }
            toastr.success("<?php echo e(session('message')); ?>");
            <?php endif; ?>
            
            <?php if(Session::has('error')): ?>
            toastr.options =
            {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-bottom-right",
            }
            toastr.error("<?php echo e(session('error')); ?>");
            <?php endif; ?>
            
            <?php if(Session::has('info')): ?>
            toastr.options =
            {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-bottom-right",
            }
            toastr.info("<?php echo e(session('info')); ?>");
            <?php endif; ?>
            
            <?php if(Session::has('warning')): ?>
            toastr.options =
            {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-bottom-right",
            }
            toastr.warning("<?php echo e(session('warning')); ?>");
            <?php endif; ?>


            <?php if(Session::has('status')): ?>
            toastr.options =
            {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-bottom-right",
            }
            toastr.success("<?php echo e(session('status')); ?>");
            <?php endif; ?>



            }); 
        </script>

        <?php echo $__env->make('layouts.page.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('style'); ?>
        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html><?php /**PATH /home/getuphostingcom/public_html/resources/views/layouts/page/pageLayout.blade.php ENDPATH**/ ?>