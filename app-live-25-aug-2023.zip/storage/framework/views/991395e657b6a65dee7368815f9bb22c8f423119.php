
<?php $__env->startSection('title', 'Admin | Leads'); ?> 
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        
                        <h1 class="page-header">Leads
                            

                            
                        </h1>
                        
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php 
                $userdata = App\Models\User::find(auth()->user()->id);
                $permissiondata = $userdata->permissions()->pluck('name');
            ?>
            <?php if($permissiondata->contains('leads.index') || $userdata->id==1): ?>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables1">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Subject / Enquiry</th>
                                        <th>Source</th>
                                        <th>Action</th>
                                        <th>Subscriber</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i = 1; 
                                    $leads = App\Models\Contact::all();
                                    ?>
                                    <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td class="main_page_title"><?php echo e($lead->name); ?></td>
                                        <td class="main_page_title"><?php echo e($lead->email); ?></td>
                                        <td class="main_page_title"><?php echo e($lead->phone); ?></td>
                                        <td class="main_page_title"><?php echo e($lead->subject); ?></td>
                                        <td class="main_page_title"><?php echo e($lead->source); ?></td>
                                        <td>
                                            <?php if($permissiondata->contains('leads.delete') || $userdata->id==1): ?>
                                            <form action="<?php echo e(route('admin.dashboard.lead.delete', $lead->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" id="deleteFormBtn" onclick="return confirm('<?php echo e(__('Are you sure you want to delete?')); ?>')">
                                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </td>
                                        <?php
                                            $user = App\Models\User::where("email","=",$lead->email)->first();
                                        ?>
                                        <td>
                                            <?php if($user): ?>
                                            <?php if($user->subscription == NULL): ?>
                                            <a href="<?php echo e(route('admin.dashboard.subscriber.edit', $user->id)); ?>?page=leads">Add as subscriber</a>
                                            <?php else: ?>
                                            Subscribed
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                </div>
            </div>
            <!-- /.col-lg-4 -->
            <?php else: ?>
            <div class="permission_restricted">You don't have permission to view this page.</div>
            <?php endif; ?>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#dataTables1').DataTable({
            responsive: true
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/backend/leads/index.blade.php ENDPATH**/ ?>