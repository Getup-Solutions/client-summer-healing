
<?php $__env->startSection('title', 'Admin | Orders'); ?> 
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        
                        <h1 class="page-header">Orders
                            
                            <?php          
                                $userdata = App\Models\User::find(auth()->user()->id);
                                $permissiondata = $userdata->permissions()->pluck('name');
                                //dd($permissiondata);
                            ?>
                            <?php if($permissiondata->contains('orders.index') || $userdata->id == 1): ?>
                            <span>
                                <a class="bgcolorOne" href="<?php echo e(route('admin.export-orders')); ?>">
                                <i class="fa fa-plus" aria-hidden="true"></i>
                                 Export</a>
                            </span>
                            <?php endif; ?>
                        </h1>
                        
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            

            <?php if($permissiondata->contains('orders.index') || $userdata->id == 1): ?>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables1">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Order Date</th>
                                        <th>Name</th>
                                        <th>Course</th>
                                        <th>Quantity</th>
                                        <th>Total</th>
                                        <th>Phone</th>
                                        <th>Subscriber</th>
                                        <th>Type</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td class="main_page_title"><?php echo e($order->created_at); ?></td>
                                        <td class="main_page_title"><?php echo e($order->username); ?></td>
                                        <td class="main_page_title"><?php echo e($order->course); ?></td>
                                        <td class="main_page_title"><?php echo e($order->quantity); ?></td>
                                        <td class="main_page_title">$<?php echo e($order->total); ?></td>
                                        <td class="main_page_title"><?php echo e($order->userphone); ?></td>
                                        <td class="main_page_title"><?php echo e(strtolower($order->useremail)); ?></td>
                                        <td class="main_page_title"><?php echo e($order->type == "course" ? "Course" : "Training"); ?></td>
                                        

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>

                  
                </div>
             
            </div>
            <?php else: ?>
            <div class="permission_restricted">You don't have permission to view this page.</div>
            <?php endif; ?>
            <!-- /.col-lg-4 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#dataTables1').DataTable({
            responsive: true,
            pageLength: 30
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/backend/orders/index.blade.php ENDPATH**/ ?>