<?php $__env->startSection('title', 'Admin | Add Course'); ?>

<?php $__env->startSection('content'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<div id="page-wrapper">

    <div class="container-fluid">

            <div class="row">

                <div class="col-lg-12">

                    <div class="row">

                        <h1 class="page-header">Add Class <span></h1>

                    </div>

                </div>

                <!-- /.col-lg-12 -->

            </div>

            <?php          

                $userdata = App\Models\User::find(auth()->user()->id);

                $permissiondata = $userdata->permissions()->pluck('name');

                //dd($permissiondata);

            ?>



            <?php if($permissiondata->contains('courses.create') && $permissiondata->contains('courses.index')  || $userdata->id == 1): ?>

            <!-- /.row -->

            <div class="row">

                <div class="col-lg-12 col-md-12">

                    <div class="panel panel-default">

                        <div class="panel-body">

                            <div class="row">



                                <?php if(isset($_GET['coursetype']) == "course" || isset($_GET['coursetype']) == 'ondemand'): ?>



                                <form role="form" style="padding:1rem 2rem;" method="post" action="<?php echo e(route('admin.dashboard.courses.store')); ?>" enctype="multipart/form-data">

                                    <?php echo csrf_field(); ?>

      

                                    <div class="form-group">

                                        <label>Title <span style="color:red">*</span></label>

                                        <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title" value="<?php echo e(old('title')); ?>">

                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                            <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                        

                                    <div class="form-group">

                                        <label>Description</label>

                                        <textarea class="form-control  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description" name="description"><?php echo e(old('description')); ?></textarea>

                                    </div>

                                    

                                    <div class="form-group">

                                        <label>Excerpt</label>

                                        <textarea class="form-control  <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description2" name="excerpt"><?php echo e(old('excerpt')); ?></textarea>

                                    </div>



                                    <div class="form-group banner-image-field">

                                        <label>Featured Image</label>

                                        <input type="file" id="featured_image" name="featured_image">

                                        

                                    </div>



                                    <div class="row mb-5 col-md-12" id="img_crop_and_container" style="display:none;margin-bottom:3rem;">

                                        <div class="img_crop_div1 col-md-7">

                                            <div id="cropie-demo" style="width:250px;height:auto;"></div>

                                            <a href="#" class="btn btn-success upload-result">Crop Image</a>

                                        </div>

                                        <div class="img_crop_div1 col-md-5">

                                            <div id="image-preview" style="background:#e1e1e1;padding:0px;height:300px;display:none;text-align:center;align-content:center;justify-content:center;}"></div>

                                        </div>

                                    </div>



                                    <div class="form-group">

                                        <label>Course Category <span style="color:red">*</span></label>

                                        <select name="course_category" id="course_category" class="form-control <?php $__errorArgs = ['course_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="course_category">

                                            <option value="" selected disabled>--SELECT CATEGORY--</option>

                                            <?php $__currentLoopData = $admincoursecats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admincoursecat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option value="<?php echo e($admincoursecat->id); ?>" <?php if(old('course_category') == $admincoursecat->id): ?> selected <?php endif; ?>><?php echo e($admincoursecat->title); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>

                                        <?php $__errorArgs = ['course_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                            <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>



                                    <div class="form-group">

                                        <label>Subscription Plan <span style="color:red">*</span></label>

                                        <select name="subscription[]" id="subscription" multiple="multiple" class="form-control <?php $__errorArgs = ['subscription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="subscription">


                                            <?php $__currentLoopData = $adminsubscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminsubscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option value="<?php echo e($adminsubscription->id); ?>" <?php if(old('subscription') == $adminsubscription->id): ?> selected <?php endif; ?>><?php echo e($adminsubscription->title); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>

                                        <?php $__errorArgs = ['subscription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                            <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>



                                    <div class="form-group">

                                        <label>Trainers</label>

                                        <select class="form-control" id="trainers" name="trainers[]" multiple="multiple">

                                            <?php $__currentLoopData = $admintrainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admintrainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option value="<?php echo e($admintrainer->id); ?>"><?php echo e($admintrainer->trainer_name); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>

                                    </div>



                                    <div class="form-group">

                                        <label>Course Level</label>

                                        <select name="level" id="level" class="form-control" id="level">

                                            <option value="">--SELECT LEVEL--</option>

                                            <option value="All" <?php if(old('level') == "All"): ?> selected <?php endif; ?>>All</option>

                                            <option value="Beginner" <?php if(old('level') == "Beginner"): ?> selected <?php endif; ?>>Beginner</option>

                                            <option value="Intermediate" <?php if(old('level') == "Intermediate"): ?> selected <?php endif; ?>>Intermediate</option>

                                            <option value="Advanced" <?php if(old('level') == "Advanced"): ?> selected <?php endif; ?>>Advanced</option>

                                        </select>

                                    </div>



                                    <div class="form-group">

                                        <label>Price <span style="color:red">*</span></label>

                                        <input class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="price" name="price" value="<?php echo e(old('price')); ?>">

                                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                            <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>



                                    <div class="form-group">

                                        <label>Status</label>

                                        <select name="status" id="status" class="form-control" id="status">

                                            <option value="Published">Published</option>

                                            <option value="Draft">Draft</option>

                                        </select>

                                    </div>



                                    <div class="panel-heading-seo">

                                        VIDEO OPTIONS

                                    </div>



                                    



                                    <div class="form-group">

                                        <label>Video Embed URL. <span style="color:red">*</span></label>

                                        <div class="samplecode">

                                            <p>copy the Iframe sample to this field and change src URL(YOUTUBE EMBED URL ONLY!)</p>

                                            <pre>&lt;iframe src="https://www.youtube.com/embed/D0UnqGm_miA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen&gt;&lt;/iframe&gt;</pre>

                                        </div>

                                        <textarea class="form-control <?php $__errorArgs = ['embed_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="embed_url" name="embed_url" style="height: 120px; font-weight:700;" placeholder="This is a sample Iframe code and please copy to the video embed URL field and change src URL(YOUTUBE EMBED URL)"><?php echo e(old('embed_url')); ?></textarea>

                                                                            <?php $__errorArgs = ['embed_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>







                                    <input type="hidden" name="coursetype" value="<?php echo e($_GET['coursetype']); ?>">



                                    <input id="finalImageValue" name="finalImageValue" value="" type="hidden">



                                    <div class="rightSideBtn">

                                    <button type="submit" class="btn btn-default common-button" id="createBtn"><i class="fa fa-floppy-o" aria-hidden="true"></i> Create</button>

                                    </div>

                                </form>

                                <?php else: ?>

                                <p style="color:red; text-align:center;">YOU HAVE NO ACCESS TO THIS PAGE.</p>

                                <p style="text-align:center">

                                    <a class="btn btn-success" href="<?php echo e(route('admin.dashboard.courses.create')); ?>?coursetype=course">Add New Course</a>

                                    <a class="btn btn-success" href="<?php echo e(route('admin.dashboard.courses.create')); ?>?coursetype=ondemand">Add New Ondemand Course</a>

                                </p>

                                <?php endif; ?>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <!-- /.col-lg-4 -->

        </div>

        <!-- /.row -->

        <?php else: ?>

            <div class="permission_restricted">You don't have permission to view this page.</div>

        <?php endif; ?>

    </div>

    <!-- /.container-fluid -->

</div>

<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>



<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>



<link href="<?php echo e(asset('backend/css/jquery.datetimepicker.css')); ?>" rel="stylesheet" type="text/css">

<script src="<?php echo e(asset('backend/js/jquery.datetimepicker.js')); ?>"></script>

<script src="https://cdn.tiny.cloud/1/n2590ka2n2b7p5syrrlwvtbjcfea73z84bekfmy13ihsxo2k/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.2/croppie.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.2/croppie.js"></script>

<script>

    //tinymce cloud

    tinymce.init({

        selector: 'textarea#description,textarea#description2',

        height: 300,

        plugins: 'preview importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap pagebreak nonbreaking anchor insertdatetime advlist lists wordcount help charmap quickbars emoticons',

        toolbar: 'code | undo redo | bold italic underline strikethrough | fontfamily fontsize blocks | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | forecolor backcolor removeformat | pagebreak | charmap emoticons | fullscreen  preview save print | insertfile image media template link anchor codesample | ltr rtl',

        toolbar_sticky: true,

        autosave_ask_before_unload: true,

        autosave_interval: "30s",

        autosave_prefix: "{path}{query}-{id}-",

        autosave_restore_when_empty: false,

        autosave_retention: "2m",

        image_advtab: true,

        toolbar_mode: 'sliding',

        contextmenu: "link image imagetools table",

    });



    //Preview image on select

    function readURL(input) {

        if (input.files && input.files[0]) {

            var reader = new FileReader();

            reader.onload = function (e) {

                $('#featured_image_src').css("display", "block");

                $('#featured_image_src').attr('src', e.target.result);

            }

            reader.readAsDataURL(input.files[0]);

        }

    }

    $("#featured_image").change(function(){

        $('#featured_image_src').css("display", "block");

        readURL(this);

    });



    $(document).ready(function() {

        $('#subscription').select2();
        $('#trainers').select2();



        jQuery('#timeClock').click(function(){

            jQuery('#myDatePicker').datetimepicker('show');

        });



        $('#myDatePicker').datetimepicker({

            format:'H:i A',

            datepicker:false,

            step:15,

            inline:false,

            hours12:true,



            onChangeDateTime:function(dp,$input){

                $('.timoutputlist').val($input.val());

            }



        });







        //image cropie



        $.ajaxSetup({

            headers: {

                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

            }

        });



        $uploadCrop = $('#cropie-demo').croppie({

            enableExif: true,

            enableResize: true,

            viewport: {

                width: 450,

                height: 250,

                // type: 'circle'

            },

            boundary: {

                width: 500,

                height: 300

            }

        });





        $('#featured_image').on('change', function() {

            var reader = new FileReader();

            reader.onload = function(e) {

                $uploadCrop.croppie('bind', {

                    url: e.target.result

                }).then(function() {

                    console.log('jQuery bind complete');

                });

            }

            reader.readAsDataURL(this.files[0]);

        });





        $('.upload-result').on('click', function(ev) {

            ev.preventDefault();

            $uploadCrop.croppie('result', {

                type: 'canvas',

                size: 'viewport'

            }).then(function(resp) {

                $.ajax({

                    url: "/admin/course/image-crop-class",

                    type: "POST",

                    data: {

                        "featured_image": resp

                    },

                    success: function(data) {

                        $('#image-preview').css("display", "flex");

                        html = '<img src="' + resp + '" />';

                        $("#image-preview").html(html);

                        $("#finalImageValue").val(data.image);

                        console.log(resp);

                    }

                });

            });

        });

        

        

        

        

                                                

        $("#featured_image").change(function(){

            $("#img_crop_and_container").show();

        });

        

        

        //DISABLE PREVIOUS DATES ON DATE PICKERS

         var today = new Date();

        var dd = String(today.getDate()).padStart(2, '0');

        var mm = String(today.getMonth() + 1).padStart(2, '0');

        var yyyy = today.getFullYear();



        today = yyyy + '-' + mm + '-' + dd;

        $('#scheduledate').attr('min',today);





    });

    

</script>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/backend/courses/create.blade.php ENDPATH**/ ?>