<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title', 'Trainings | Summer Healing Society'); ?>

<?php $__env->startSection('meta_keyword', 'Trainings'); ?>

<?php $__env->startSection('meta_description', 'Trainings'); ?>



<!-- PAGE HEADING START -->

<section class="set-top-spacing position-relative overflow-hidden">

    <div class="content d-flex align-items-center justify-content-center">

      <div class="container-fluid w-100">

        <div class="row">

          <div class="col-12 text-center mt-3 mt-sm-0">

            <h1

              class="display-2 font-weight-700 text-uppercase"

              data-sal="slide-up"

              style="--sal-duration: 1s"

            >

              Training

            </h1>

          </div>

        </div>

      </div>

    </div>

  </section>

  <!-- PAGE HEADING END -->

  <!-- PLANS START -->

  <section class="yoga-training yoga-training-inner spacing-100 pb-0">

    <div class="container-fluid text-center text-md-start">

      <div class="row">

        <div class="col-xl-11 mx-auto">

          <div class="row row-equl" id="#trainingCourses">

            <!-- ITEM START -->



            <?php

              $allTrainings = App\Models\Admintraining::all();

            ?>

            <?php $__currentLoopData = $allTrainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-xl-4 col-lg-6 mb-5" data-sal="slide-up" style="--sal-duration: 1s">

              <div class="card text-center mx-2">

                <div class="top">

                   <img src="Frontend/assets/images/loading.gif" data-src="<?php echo e(asset('backend/images/trainings_images')); ?>/<?php echo e($training->image); ?>"  class="d-block w-100 lazy trainingimage" alt="...">

                </div>

                <div class="content">

                  <div class="middle">

                    <a href="<?php echo e(route('page.training.detailed', $training->id)); ?>"><h4 class="h4 font-weight-700 text-uppercase main-title"><?php echo e($training->title); ?></h4></a>

                    

                  </div>

                  <div class="bottom w-100 d-sm-flex align-items-end justify-content-center">

                    <?php if(auth()->check()): ?>

                        <?php

                          $allOrders = App\Models\Order::where('useremail', auth()->user()->email)->where('type','training')->pluck('training_id');

                        ?>

                    <?php endif; ?>

                    <?php if(auth()->check()): ?>

                      <?php if($allOrders->contains($training->id)): ?>

                          <a href="<?php echo e(route('page.training.detailed', $training->id)); ?>" class="btn me-3 w-100">More Info</a>

                      <?php else: ?>

                          <a href="<?php echo e(route('page.training.detailed', $training->id)); ?>" class="btn me-3 w-100">More Info</a>

                          <a href="<?php echo e(route('page.training.purchase', $training->id)); ?>" class="btn btn-primary w-100 mt-3 mt-sm-0">Join Now</a>

                      <?php endif; ?>

                    <?php else: ?>

                      <a href="<?php echo e(route('page.training.detailed', $training->id)); ?>" class="btn me-3 w-100">More Info</a>

                      <a href="<?php echo e(route('page.training.purchase', $training->id)); ?>" class="btn btn-primary w-100 mt-3 mt-sm-0">Join Now</a>

                    <?php endif; ?>

                  </div>

                </div>

              </div>

            </div>

            <!-- ITEM END -->

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

          </div>

        </div>

      </div>

    </div>

  </section>

  <!-- PLANS END -->





  <?php $__env->stopSection(); ?>



<?php $__env->startSection('style'); ?>

<style>

   .d-block.w-100.lazy.trainingimage {

    height: 300px;

    object-fit: cover;

    object-position: top;

  }

</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page.pageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/frontend/pages/trainings.blade.php ENDPATH**/ ?>