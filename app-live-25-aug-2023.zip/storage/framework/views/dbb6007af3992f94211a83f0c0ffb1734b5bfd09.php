
<?php $__env->startSection('title', 'Admin | Course Schedule'); ?>
   
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <h1 class="page-header">Schedules
                            <span>
                                <a class="bgcolorOne" href="<?php echo e(route('admin.dashboard.schedulez.scheduleindex')); ?>">
                                <i class="fa fa-plus" aria-hidden="true"></i>
                                 Add Schedule</a>
                            </span>
                        </h1>
                        
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
    </div>

    <div class="container-fluid" id="scheduleGridContainer">
        <div class="row">
            <?php $__currentLoopData = $schedulez; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        
                        <?php
                            $fullDay = date('l', strtotime($schedule->scheduledate));
                            $dateInt = date('jS M Y', strtotime($schedule->scheduledate));
                            //$monthStr = date('M', strtotime($schedule->scheduledate));
                            //dd($monthInt);
                            $allCourses = App\Models\Admincourse::where(['status'=>'Published'])->get();
                            $findCourseExists = $allCourses->contains($schedule->courseid);
                            //dd($findCourseExists);
                        ?>

                        <?php echo e($fullDay); ?>, <?php echo e($dateInt); ?>

                    </div>
                    <?php if($findCourseExists == true): ?>
                    <div class="panel-body scheduleItemDivWrapper equalHeight">
                        <div><b>Course:</b> <?php echo e(strtoupper($schedule->title)); ?></div>
                        <div><b>Date:</b> <?php echo e(date('d-m-Y', strtotime($schedule->scheduledate))); ?></div>
                        <div><b>Time Start:</b> <?php echo e($schedule->scheduletime); ?></div>
                        
                        <?php if($schedule->type != "recurring"): ?>
                        <div><b>Duration:</b>
                            <?php
                                $starttime = date("g:ia", strtotime($schedule->scheduletime));
                                $endtime = date("g:ia", strtotime($schedule->scheduletimeend));
                                $start = Carbon\Carbon::parse($starttime);
                                
                                $end = Carbon\Carbon::parse($endtime); 
                                //dd($end->diffInMinutes($start));
                                if($end->diffInMinutes($start) > 15){
                                    echo $end->diffInMinutes($start) . " min";
                                }
                                if($end->diffInHours($start) > 15){
                                    echo $end->diffInHours($start) * 3600 / 60 . " min";
                                }
                            ?>
                        </div>
                        <?php endif; ?>
                        
                        <div><b>Type:</b> <?php echo e(ucfirst($schedule->schedule_type)); ?> Schedule</div>
                        <div><b>Status:</b> <?php echo e($schedule->status); ?></div>
                        <div><b>Created On:</b> <?php echo e($schedule->created_at); ?></div>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </div>
                    <?php else: ?>
                    <div class="panel-body scheduleItemDivWrapper equalHeight">
                        <div class="scheduleCourseNotFound"><b>The course under this schedule is not available or removed. <br/>Please edit and choose a course.</div>
                    </div>
                    <?php endif; ?>
                    <div class="panel-footer">
                    <?php if($schedule->schedule_type == "recurring"): ?>
                    <a href="<?php echo e(route('admin.dashboard.schedule.editRecurring', $schedule->id)); ?>" class="btn btn-block btn-social btn-github"><i class="fa fa-pencil-square-o"></i> </a> 
                    <?php else: ?>
                    <a href="<?php echo e(route('admin.dashboard.schedule.editCoursechedule', $schedule->id)); ?>" class="btn btn-block btn-social btn-github"><i class="fa fa-pencil-square-o"></i> </a> 
                    <?php endif; ?>
                    <?php if($findCourseExists == true): ?>
                    <a href="<?php echo e(route('admin.dashboard.schedulez.scheduleview', $schedule->id)); ?>" class="btn btn-block btn-social btn-facebook"><i class="fa fa-eye"></i> </a>
                    <?php endif; ?>
                    

                    <form action="<?php echo e(route('admin.dashboard.schedulez.scheduledelete', $schedule->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-block btn-social btn-pinterest" style="height: 35px;padding:0 20px;width:35px;vertical-align: text-bottom;" onclick="return confirm('<?php echo e(__('Are you sure you want to delete?')); ?>')">
                            <i class="fa fa-trash-o"></i>
                        </button>
                    </form>
    
                    </div>
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="schedule-paginate">
                <br/>
                <br/>
                <?php echo $schedulez->links(); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    (function () {
      equalHeight(false);
    })();
     
    window.onresize = function(){
      equalHeight(true);
    }
     
    function equalHeight(resize) {
      var elements = document.getElementsByClassName("equalHeight"),
          allHeights = [],
          i = 0;
      if(resize === true){
        for(i = 0; i < elements.length; i++){
          elements[i].style.height = 'auto';
        }
      }
      for(i = 0; i < elements.length; i++){
        var elementHeight = elements[i].clientHeight;
        allHeights.push(elementHeight);
      }
      for(i = 0; i < elements.length; i++){
        elements[i].style.height = Math.max.apply( Math, allHeights) + 'px';
        if(resize === false){
          elements[i].className = elements[i].className + " show";
        }
      }
    }
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    #scheduleGridContainer a {
        color: #fff;
        height: 35px;
        width: 30px;
        margin-right: 8px;
        padding-right: 0;
    }
    .panel-default > .panel-heading {
        font-size: 17px;
        font-weight: 600;
        color: #fff;
        background-color: #bb8a45;
        border: 1px solid #bb8a45;
    }
    .btn-social > :first-child {
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 32px;
        line-height: 34px;
        font-size: 1.4em;
        text-align: center;
        right: 0;
        margin: 0 auto;
        border-right: 0;
    }
    .panel-footer {
        display: flex;
        align-items: flex-end;
        text-align:right;
        justify-content: flex-end;
    }
    .schedule-paginate .hidden {
        display: block !important;
        visibility: visible !important;
    }
    .schedule-paginate .hidden svg {
        width: 30px;
        vertical-align: middle;
    }
    .schedule-paginate .hidden a{color: #363636!important;}
    .schedule-paginate .flex.items-center.justify-between div.flex {
        display: none;
    }
    .relative.inline-flex.items-center.px-4.py-2.-ml-px.text-sm.font-medium.text-gray-500.bg-white.border.border-gray-300.cursor-default.leading-5 {
        background: #bb8a45;
        color: #fff;
        display: inline-block;
        padding: 5px 10px;
        margin: 0 2px;
    }
    .relative.inline-flex.items-center.px-4.py-2.-ml-px.text-sm.font-medium.text-gray-700.bg-white.border.border-gray-300.leading-5.hover\:text-gray-500.focus\:z-10.focus\:outline-none.focus\:ring.ring-gray-300.focus\:border-blue-300.active\:bg-gray-100.active\:text-gray-700.transition.ease-in-out.duration-150 {
        background: #363636;
        color: #fff !important;
        display: inline-block;
        padding: 5px 10px;
        margin: 0 2px !important;
        height: auto !important;
        width: auto !important;
        padding-right: 10px !important;
        text-decoration: none;
    }
    .schedule-paginate {
        text-align: center;
        float: left;
        width: 100%;
        margin-top: 1rem;
    }
    .schedule-paginate .text-sm.text-gray-700.leading-5 {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/backend/schedulez/schedules.blade.php ENDPATH**/ ?>