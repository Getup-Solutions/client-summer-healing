
<?php $__env->startSection('title', 'Admin | Schedule'); ?>
   
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <h1 class="page-header">Add Schedule
                            
                        </h1>
                        
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
    </div>


    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="newScheduleBtnnWrap">
                <a class="newScheduleBtnn" href="<?php echo e(route('admin.dashboard.schedule.newCourse')); ?>">
                    <i class="fa fa-plus" aria-hidden="true"></i>
                    Create single course schedule</a>
                </a>

            </div>
            <div class="newScheduleBtnnWrap">
                <a class="newScheduleBtnn" href="<?php echo e(route('admin.dashboard.schedule.recurring.newCourse')); ?>">
                    <i class="fa fa-plus" aria-hidden="true"></i>
                    Create recurring course schedule</a>
                </a>
            </div>
            </div>
        </div>
    </div>



</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/backend/schedulez/index.blade.php ENDPATH**/ ?>