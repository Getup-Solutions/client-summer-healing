
<?php $__env->startSection('title', 'Admin | All Pages'); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        
                        <h1 class="page-header">Pages 
                            <?php if(auth()->check()): ?>
                                <?php if(auth()->user()->type == "superadmin"): ?>
                                    <span>
                                        <a class="bgcolorThree" href="<?php echo e(route('admin.dashboard.pages.trash')); ?>">
                                        <i class="fa fa-trash" aria-hidden="true"></i>
                                        Trash list</a>
                                        
                                        <a class="bgcolorOne" href="<?php echo e(route('admin.dashboard.page.create')); ?>">
                                        <i class="fa fa-plus" aria-hidden="true"></i>
                                        Add New</a>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </h1>
                        
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php
                
                $userdata = App\Models\User::find(auth()->user()->id);
                $permissiondata = $userdata->permissions()->pluck('name');
                //dd($permissiondata);
            ?>
            <?php if($permissiondata->contains('pages.index') || $userdata->id==1): ?>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables1">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Banner Image</th>
                                        <th>Date of created</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1 ?>
                                    <?php if(count($adminpages) > 0): ?>
                                    <?php $__currentLoopData = $adminpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminpage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td class="main_page_title"><strong><?php echo e($adminpage->title); ?></strong></td>
                                        <td>
                                            <img style="width:100px;" src="<?php echo e(url("/backend/images/banner_images")); ?>/<?php echo e($adminpage->banner_image); ?>"alt="<?php echo e($adminpage->banner_image); ?>">
                                        </td>
                                        <td><?php echo e($adminpage->created_at); ?></td>
                                        <td><?php echo e($adminpage->status == 1 ? "Published" : "Draft"); ?></td>
                                        <td>
                                            <ul class="actionList">
                                                
                                            <li><a href="<?php echo e(route('admin.dashboard.page.edit', $adminpage->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></li>
                                            <?php if(auth()->check()): ?>
                                                <?php if(auth()->user()->type == "superadmin"): ?>
                                                    <li>
                                                
                                                        <form action="<?php echo e(route('admin.dashboard.page.destroy', $adminpage->id)); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" id="deleteFormBtn" onclick="return confirm('<?php echo e(__('Are you sure you want to delete?')); ?>')">
                                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                                            </button>
                                                        </form>
                                                    
                                                    </li>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                </ul>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td rowspan="10" colspan="10" style="text-align: center">No pages found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>

                  
                </div>
             
            </div>

            <?php else: ?>
            <div class="permission_restricted">You don't have permission to view this page.</div>
            <?php endif; ?>
     
            <!-- /.col-lg-4 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    $(document).ready(function() {
        $('#dataTables1').DataTable({
            responsive: true
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/backend/pages/index.blade.php ENDPATH**/ ?>