
<?php $__env->startSection('title', 'Admin | Edit Page'); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <h1 class="page-header">Edit <?php echo e($adminpage->title); ?> Page <span></h1>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <?php          
                $userdata = App\Models\User::find(auth()->user()->id);
                $permissiondata = $userdata->permissions()->pluck('name');
            ?>
            <?php if($permissiondata->contains('pages.edit') || $userdata->id == 1): ?>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <form role="form" style="padding:1rem 2rem;" method="post" action="<?php echo e(route('admin.dashboard.page.update', $adminpage->id)); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <?php if($adminpage->slug === "terms" || $adminpage->slug === "privacy-policy" || $adminpage->slug === "refund-policy"): ?>
                                        <div class="form-group">
                                            <label>Page Title</label>
                                            <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title" value="<?php echo e($adminpage->title); ?>">
                                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label>Description</label>
                                            <textarea class="form-control  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description" name="description"><?php echo e($adminpage->description); ?></textarea>
                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="panel-heading-seo">
                                            PAGE BANNER
                                        </div>

                                        <div class="form-group banner-image-field">
                                            <label>Banner Image</label>
                                            <input type="file" id="banner_image" name="banner_image">
                                            <img id="banner_image_src" src="<?php echo e(url('/backend/images/banner_images')); ?>/<?php echo e($adminpage->banner_image); ?>" alt="banner image">
                                        </div>

                                        <div class="panel-heading-seo">
                                            SEARCH ENGINE OPTIMISATION (SEO)
                                        </div>
    
                                        <div class="form-group">
                                            <label>SEO Title</label>
                                            <input class="form-control" type="text" id="seo_title" name="seo_title" value="<?php echo e($adminpage->seo_title); ?>">
                                        </div>
    
                                        <div class="form-group">
                                            <label>SEO Description</label>
                                            <input class="form-control" type="text" id="seo_description" name="seo_description" value="<?php echo e($adminpage->seo_description); ?>">
                                        </div>
    
                                        <div class="form-group">
                                            <label>SEO Keyword</label>
                                            <input class="form-control" type="text" id="seo_keyword" name="seo_keyword" value="<?php echo e($adminpage->seo_keyword); ?>">
                                        </div>
    
                                        <div class="form-group">
                                            <label>Status</label>
                                            <select name="status" id="status" class="form-control">
                                                <option value="1" 
                                                <?php echo e($adminpage->status == 1 ? 'selected' : ''); ?>>Publish</option>
                                                <option value="0" <?php echo e($adminpage->status == 0 ? 'selected' : ''); ?>>Draft</option>
                                            </select>
                                        </div>
                                    <?php else: ?>
                                    
                                    <div class="form-group">
                                        <label>Page Title</label>
                                        <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title" value="<?php echo e($adminpage->title); ?>">
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="formAlertError alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="panel-heading-seo">
                                        PAGE BANNER
                                    </div>

                                    <div class="form-group banner-image-field">
                                        <label>Banner Image</label>
                                        <input type="file" id="banner_image" name="banner_image">
                                        <img id="banner_image_src" src="<?php echo e(url('/backend/images/banner_images')); ?>/<?php echo e($adminpage->banner_image); ?>" alt="banner image">
                                    </div>

                                    <div class="panel-heading-seo">
                                        OTHER SECTIONS
                                     </div>

                                    <div class="form-group banner-image-field">
                                        <label>Section 1 heading</label>
                                        <input type="text" class="form-control" id="section1_heading" name="section1_heading" value="<?php echo e($adminpage->section1_heading); ?>">
                                    </div>
 
                                     <div class="form-group">
                                         <label>Section 1</label>
                                         <textarea class="form-control" id="description" name="section1"><?php echo e($adminpage->section1); ?></textarea>
                                     </div>

                                     <div class="form-group banner-image-field">
                                        <label>Section 2 heading</label>
                                        <input type="text" class="form-control" id="section2_heading" name="section2_heading" value="<?php echo e($adminpage->section2_heading); ?>">
                                    </div>
 
                                     <div class="form-group">
                                         <label>Section 2</label>
                                         <textarea class="form-control" id="description2" name="section2"><?php echo e($adminpage->section2); ?></textarea>
                                     </div>

                                     <div class="form-group banner-image-field">
                                        <label>Section 3 heading</label>
                                        <input type="text" class="form-control" id="section3_heading" name="section3_heading" value="<?php echo e($adminpage->section3_heading); ?>">
                                    </div>
 
                                     <div class="form-group">
                                         <label>Section 3</label>
                                         <textarea class="form-control" id="description3" name="section3"><?php echo e($adminpage->section3); ?></textarea>
                                     </div>

                                     <div class="form-group banner-image-field">
                                        <label>Section 4 heading</label>
                                        <input type="text" class="form-control" id="section4_heading" name="section4_heading" value="<?php echo e($adminpage->section4_heading); ?>">
                                    </div>
 
                                     <div class="form-group">
                                         <label>Section 4</label>
                                         <textarea class="form-control" id="description4" name="section4"><?php echo e($adminpage->section4); ?></textarea>
                                     </div>

                                    <?php if($adminpage->slug === "home"): ?>
                                    <div class="form-group banner-image-field">
                                        <label>Section 5 heading</label>
                                        <input type="text" class="form-control" id="section5_heading" name="section5_heading" value="<?php echo e($adminpage->section5_heading); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label>Section 5</label>
                                        <textarea class="form-control" id="description5" name="section5"><?php echo e($adminpage->section5); ?></textarea>
                                    </div>

                                    <div class="form-group banner-image-field">
                                        <label>Section 6 heading</label>
                                        <input type="text" class="form-control" id="section6_heading" name="section6_heading" value="<?php echo e($adminpage->section6_heading); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label>Section 6</label>
                                        <textarea class="form-control" id="description6" name="section6"><?php echo e($adminpage->section6); ?></textarea>
                                    </div>

                                    <div class="form-group banner-image-field">
                                        <label>Google store URl</label>
                                        <input type="text" class="form-control" id="google_store_url" name="google_store_url" value="<?php echo e($adminpage->google_store_url); ?>">
                                    </div>

                                    
                                    <div class="form-group banner-image-field">
                                        <label>Apple store URl</label>
                                        <input type="text" class="form-control" id="apple_store_url" name="apple_store_url" value="<?php echo e($adminpage->apple_store_url); ?>">
                                    </div>
                                    <?php endif; ?>

                                    <div class="panel-heading-seo">
                                        SEARCH ENGINE OPTIMISATION (SEO)
                                    </div>

                                    <div class="form-group">
                                        <label>SEO Title</label>
                                        <input class="form-control" type="text" id="seo_title" name="seo_title" value="<?php echo e($adminpage->seo_title); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label>SEO Description</label>
                                        <input class="form-control" type="text" id="seo_description" name="seo_description" value="<?php echo e($adminpage->seo_description); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label>SEO Keyword</label>
                                        <input class="form-control" type="text" id="seo_keyword" name="seo_keyword" value="<?php echo e($adminpage->seo_keyword); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label>Status</label>
                                        <select name="status" id="status" class="form-control">
                                            <option value="1" 
                                            <?php echo e($adminpage->status == 1 ? 'selected' : ''); ?>>Publish</option>
                                            <option value="0" <?php echo e($adminpage->status == 0 ? 'selected' : ''); ?>>Draft</option>
                                        </select>
                                    </div>

                                    <?php endif; ?>
                                    <div class="rightSideBtn">
                                    <button type="submit" class="btn btn-default common-button" id="createBtn"><i class="fa fa-floppy-o" aria-hidden="true"></i> Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.col-lg-4 -->
        </div>
        <!-- /.row -->
        <?php else: ?>
        <div class="permission_restricted">You don't have permission to view this page.</div>
        <?php endif; ?>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="https://cdn.tiny.cloud/1/n2590ka2n2b7p5syrrlwvtbjcfea73z84bekfmy13ihsxo2k/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
     tinymce.init({
        selector: 'textarea#description, textarea#description2, textarea#description3, textarea#description4, textarea#description5, textarea#description6',
        height: 300,
        plugins: 'preview importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap pagebreak nonbreaking anchor insertdatetime advlist lists wordcount help charmap quickbars emoticons',
        toolbar: 'code | undo redo | bold italic underline strikethrough | fontfamily fontsize blocks | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | forecolor backcolor removeformat | pagebreak | charmap emoticons | fullscreen  preview save print | insertfile image media template link anchor codesample | ltr rtl',
        toolbar_sticky: true,
        autosave_ask_before_unload: true,
        autosave_interval: "30s",
        autosave_prefix: "{path}{query}-{id}-",
        autosave_restore_when_empty: false,
        autosave_retention: "2m",
        image_advtab: true,
        toolbar_mode: 'sliding',
        contextmenu: "link image imagetools table",
    });

    //Preview image on select
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#banner_image_src').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#banner_image").change(function(){
        readURL(this);
    });


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/getuphostingcom/public_html/resources/views/backend/pages/edit.blade.php ENDPATH**/ ?>